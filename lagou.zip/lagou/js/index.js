$(function(){
	
});

window.onload = function(){
	var width = $('body').width();
	//alert(width);
	//var obj = '';
	  //obj += '<a href="###" class="swiper-slide"><img src="./logos/b1.jpg"></a>';
      //obj += '<a href="###" class="swiper-slide"><img src="./logos/b2.jpg"></a>';
      //obj += '<a href="###" class="swiper-slide"><img src="./logos/b3.jpg"></a>';
      //obj += '<a href="###" class="swiper-slide"><img src="./logos/b4.jpg"></a>';
      //$(".picmove").html(obj);
	//var len = $(".picmove a").length;
	//$('.picmove').css({
		/*'width':(width*len)+'px',
		'left':(-width)+'px',
	});
	$(".picmove a,.picmove a img").css({
		'width':width+'px',
		'height':'170px',
		'margin':0,
		'padding':0,
	});*/
	/*$(".picmove").on('swipeleft',function(){
		//alert('swipeLeft');
		$(this).animate({
			'left':"-="+width+'px',
		},function(){
			var obj = $(".picmove a").eq(0);
			$(".picmove").append(obj);
			$(this).css('left',-width*2);
		})
	});
	$(".picmove").on('swiperight',function(){
		$(this).animate({
			'left':"+="+width+'px',
		},function(){
			var obj = $(".picmove a").eq(len - 1);
			$(".picmove").prepend(obj);
			$(this).css('left',-width*2);
		});
	});*/
    var mySwiper = new Swiper('.swiper-container', {
		autoplay: 0,//可选选项，自动滑动
		initialSlide:2,
		loop:true,
		pagination: '.swiper-pagination',
		paginationType:'bullets',
	});

	/*var myScroll = new IScroll('#wrapper',{
		hScroll:true,
		vScroll:false,
	});*/

	$(".wrapper").navbarscroll();

	$(".wrapper a").on('click',function(){
		$(this).addClass('active');
		$(this).parent().siblings('li').find('a').removeClass('active');
	})

	//var myscroll = new 


}